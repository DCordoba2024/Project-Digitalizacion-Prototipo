import { Sidebar } from './components/Sidebar';
import { StatSection } from './components/StatSection';
import { OccupancyChart } from './components/OccupancyChart';
import { AttendanceChart } from './components/AttendanceChart';
import { AlertsPanel } from './components/AlertsPanel';
import { PredictionPanel } from './components/PredictionPanel';
import { FitZoneAssistant } from './components/FitZoneAssistant';
import { Search, Bell, User, Cpu, Shield, Users as UsersIcon, Activity as ActivityIcon, ShieldCheck, Brain } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useState, useEffect } from 'react';

// Simulated Telemetry State
interface Telemetry {
  temp: number;
  occupancy: number;
  activeMembers: number;
  energyUsage: number;
  airQuality: string;
}

export default function App() {
  const [activeTab, setActiveTab] = useState('overview');
  const [telemetry, setTelemetry] = useState<Telemetry>({
    temp: 22.4,
    occupancy: 48,
    activeMembers: 156,
    energyUsage: 124,
    airQuality: 'Optimum'
  });

  // Real-time Data Simulation
  useEffect(() => {
    const interval = setInterval(() => {
      setTelemetry(prev => ({
        ...prev,
        temp: Number((prev.temp + (Math.random() * 0.4 - 0.2)).toFixed(1)),
        occupancy: Math.max(10, Math.min(100, Math.round(prev.occupancy + (Math.random() * 4 - 2)))),
        activeMembers: Math.max(50, Math.round(prev.activeMembers + (Math.random() * 6 - 3))),
        energyUsage: Math.round(prev.energyUsage + (Math.random() * 10 - 5))
      }));
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const renderContent = () => {
    switch (activeTab) {
      case 'overview':
        return (
          <motion.div 
            key="overview"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-8"
          >
            <StatSection telemetry={telemetry} />
            <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
              <div className="xl:col-span-2 space-y-8">
                 <AttendanceChart />
                 <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    <OccupancyChart />
                    <PredictionPanel />
                 </div>
              </div>
              <div className="h-full">
                 <AlertsPanel />
              </div>
            </div>
          </motion.div>
        );
      case 'members':
        return (
          <motion.div 
            key="members"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="glass-panel p-8"
          >
            <div className="flex items-center gap-3 mb-6">
              <UsersIcon className="w-6 h-6 text-blue-500" />
              <h2 className="text-2xl font-display font-bold">Active Members Management</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <div className="bg-slate-900/50 p-6 rounded-2xl border border-slate-800">
                <p className="text-xs uppercase tracking-widest text-slate-500 mb-1">Live Inside</p>
                <div className="text-3xl font-display font-bold text-blue-400">{telemetry.activeMembers}</div>
              </div>
              <div className="bg-slate-900/50 p-6 rounded-2xl border border-slate-800">
                <p className="text-xs uppercase tracking-widest text-slate-500 mb-1">Peak Today</p>
                <div className="text-3xl font-display font-bold text-cyan-400">284</div>
              </div>
              <div className="bg-slate-900/50 p-6 rounded-2xl border border-slate-800">
                <p className="text-xs uppercase tracking-widest text-slate-500 mb-1">Monthly Growth</p>
                <div className="text-3xl font-display font-bold text-emerald-400">+12.4%</div>
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="text-slate-500 text-xs uppercase tracking-wider border-b border-slate-800">
                    <th className="pb-4 font-medium">Member ID</th>
                    <th className="pb-4 font-medium">Zone</th>
                    <th className="pb-4 font-medium">Equip. Usage</th>
                    <th className="pb-4 font-medium">Check-in</th>
                    <th className="pb-4 font-medium">Status</th>
                  </tr>
                </thead>
                <tbody className="text-sm">
                  {[1,2,3,4,5].map(i => (
                    <tr key={i} className="border-b border-slate-800/50 hover:bg-slate-800/30 transition-colors">
                      <td className="py-4 font-mono">USR-842{i}</td>
                      <td className="py-4">Cardio Wing B</td>
                      <td className="py-4">Treadmill #0{i}</td>
                      <td className="py-4 text-slate-500">{10+i}:15 AM</td>
                      <td className="py-4">
                        <span className="bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded text-[10px] font-bold border border-emerald-500/20">ACTIVE</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </motion.div>
        );
      case 'stats':
        return (
          <motion.div 
            key="stats"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-8"
          >
            <div className="glass-panel p-8">
               <div className="flex items-center gap-3 mb-6">
                <ActivityIcon className="w-6 h-6 text-cyan-500" />
                <h2 className="text-2xl font-display font-bold">Equipment Usage Metrics</h2>
              </div>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                 <AttendanceChart />
                 <OccupancyChart />
              </div>
            </div>
          </motion.div>
        );
      case 'security':
        return (
          <motion.div 
            key="security"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="grid grid-cols-1 lg:grid-cols-3 gap-8"
          >
            <div className="lg:col-span-2 glass-panel p-8">
              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center gap-3">
                  <ShieldCheck className="w-6 h-6 text-rose-500" />
                  <h2 className="text-2xl font-display font-bold">Security & Access Logs</h2>
                </div>
                <div className="text-[10px] bg-emerald-500/10 text-emerald-400 p-2 rounded border border-emerald-500/20 font-mono">ENCRYPTION: AES-256 ACTIVE</div>
              </div>
              
              <div className="grid grid-cols-2 gap-4 mb-8">
                <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl flex items-center justify-between">
                  <div>
                    <p className="text-[10px] font-mono text-slate-500 uppercase">Perimeter Defense</p>
                    <p className="text-lg font-display text-white">SECURE</p>
                  </div>
                  <Shield className="w-5 h-5 text-emerald-500" />
                </div>
                <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl flex items-center justify-between">
                  <div>
                    <p className="text-[10px] font-mono text-slate-500 uppercase">IoT Nodes</p>
                    <p className="text-lg font-display text-white">48/48 ONLINE</p>
                  </div>
                  <Cpu className="w-5 h-5 text-blue-500" />
                </div>
              </div>

              <div className="space-y-4">
                {[1,2,3].map(i => (
                  <div key={i} className="flex items-center justify-between p-4 bg-slate-800/30 rounded-xl border border-slate-800/50">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-slate-800 rounded-lg flex items-center justify-center font-mono text-xs">C{i}</div>
                      <div>
                        <p className="text-sm font-bold">Entrance Port {i}</p>
                        <p className="text-[10px] text-slate-500 font-mono italic">Verified Access: ID-99212</p>
                      </div>
                    </div>
                    <span className="text-[10px] text-slate-400">Just now</span>
                  </div>
                ))}
              </div>
            </div>
            <AlertsPanel />
          </motion.div>
        );
      case 'predictions':
        return (
          <motion.div 
            key="predictions"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="grid grid-cols-1 lg:grid-cols-2 gap-8"
          >
            <PredictionPanel />
            <div className="glass-panel p-8">
               <div className="flex items-center gap-3 mb-6">
                <Brain className="w-6 h-6 text-violet-500" />
                <h2 className="text-2xl font-display font-bold">Neural Forecasting</h2>
              </div>
              <p className="text-slate-400 text-sm leading-relaxed mb-6">
                The FitZone AI Engine is currently processing data from 48 localized IoT sensors. 
                Our neural models predict a <span className="text-blue-400 font-bold">24% increase</span> in attendance for 
                tomorrow morning (Tues, 07:00 AM) due to local weather events.
              </p>
              <div className="space-y-4">
                <div className="p-4 bg-violet-500/10 border border-violet-500/20 rounded-xl">
                  <h4 className="text-xs font-bold text-violet-400 mb-1">Energy Saving Opportunity</h4>
                  <p className="text-xs text-slate-400">Reduce lighting in Zone D from 2 PM to 4 PM. Predicted occupancy: 0.</p>
                </div>
                <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-xl">
                  <h4 className="text-xs font-bold text-blue-400 mb-1">Member Retention Signal</h4>
                  <p className="text-xs text-slate-400">12 members flagged as 'At Risk' based on inconsistent attendance patterns.</p>
                </div>
              </div>
            </div>
          </motion.div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="flex h-screen bg-bg-dark overflow-hidden font-sans text-slate-100">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
      
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden relative">
        {/* Background glow effects */}
        <div className="absolute top-[-10%] right-[-5%] w-[40%] h-[40%] bg-blue-600/5 blur-[120px] rounded-full pointer-events-none" />
        <div className="absolute bottom-[-10%] left-[-5%] w-[30%] h-[30%] bg-cyan-600/5 blur-[120px] rounded-full pointer-events-none" />

        {/* Top Header */}
        <header className="h-20 border-b border-slate-800 flex items-center justify-between px-8 bg-card-dark/20 backdrop-blur-sm z-10 shrink-0">
          <div className="flex items-center gap-4">
             <div>
                <h2 className="text-xl font-display font-semibold tracking-tight">FitZone Intelligence Hub</h2>
                <div className="flex items-center gap-2 mt-0.5">
                   <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-[0_0_8px_#10b981]" />
                   <p className="text-[10px] font-mono text-slate-500 uppercase tracking-widest">Neural Link Established • Zone 01 Active</p>
                </div>
             </div>
          </div>

          <div className="flex items-center gap-6">
            <div className="hidden md:flex items-center bg-slate-900 border border-slate-800 rounded-full px-4 py-2 gap-2 w-64 group focus-within:border-blue-500/50 transition-all">
              <Search className="w-4 h-4 text-slate-500 group-focus-within:text-blue-400" />
              <input 
                type="text" 
                placeholder="Search telemetry data..." 
                className="bg-transparent border-none outline-none text-xs text-slate-300 w-full placeholder:text-slate-600"
              />
            </div>
            
            <div className="flex items-center gap-4">
              <button className="p-2.5 rounded-full bg-slate-900 border border-slate-800 text-slate-400 hover:text-white transition-all relative">
                <Bell className="w-4 h-4" />
                <span className="absolute top-2 right-2 w-2 h-2 bg-rose-500 rounded-full border-2 border-slate-900" />
              </button>
              <div className="w-px h-8 bg-slate-800 mx-1" />
              <button className="flex items-center gap-3 pl-2 group">
                <div className="text-right">
                  <p className="text-xs font-bold text-slate-200">Admin_Cordoba</p>
                  <p className="text-[10px] font-mono text-blue-500 uppercase">System Operator</p>
                </div>
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center border-2 border-slate-800 group-hover:border-blue-500/50 transition-all shadow-lg">
                  <User className="text-white w-5 h-5" />
                </div>
              </button>
            </div>
          </div>
        </header>

        {/* Dashboard Content */}
        <div className="flex-1 overflow-y-auto p-8 space-y-8 custom-scrollbar relative z-10">
          
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center justify-between"
          >
            <div>
               <h1 className="text-3xl font-display font-bold tracking-tight mb-1">
                 Welcome back, <span className="text-blue-500">David</span>
               </h1>
               <p className="text-slate-400 text-sm">Facility processing cycle: {new Date().toLocaleTimeString()}</p>
            </div>
            <div className="flex gap-2">
               <button className="flex items-center gap-2 bg-slate-900 border border-slate-800 px-4 py-2 rounded-xl text-xs font-medium text-slate-400 hover:bg-slate-800 transition-all">
                  <Cpu className="w-4 h-4" /> Hardware Status
               </button>
               <button className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-xl text-xs font-bold shadow-lg shadow-blue-600/20 hover:bg-blue-500 transition-all">
                  <Shield className="w-4 h-4" /> Emergency Protocol
               </button>
            </div>
          </motion.div>

          <AnimatePresence mode="wait">
            {renderContent()}
          </AnimatePresence>
        </div>
      </main>

      <FitZoneAssistant />
    </div>
  );
}
