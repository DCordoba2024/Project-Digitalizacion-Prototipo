import { Sidebar } from './components/Sidebar';
import { StatSection } from './components/StatSection';
import { OccupancyChart } from './components/OccupancyChart';
import { AttendanceChart } from './components/AttendanceChart';
import { AlertsPanel } from './components/AlertsPanel';
import { PredictionPanel } from './components/PredictionPanel';
import { FitZoneAssistant } from './components/FitZoneAssistant';
import { Search, Bell, User, Cpu, Shield } from 'lucide-react';
import { motion } from 'motion/react';

export default function App() {
  return (
    <div className="flex h-screen bg-bg-dark overflow-hidden font-sans text-slate-100">
      <Sidebar />
      
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden relative">
        {/* Background glow effects */}
        <div className="absolute top-[-10%] right-[-5%] w-[40%] h-[40%] bg-blue-600/5 blur-[120px] rounded-full pointer-events-none" />
        <div className="absolute bottom-[-10%] left-[-5%] w-[30%] h-[30%] bg-cyan-600/5 blur-[120px] rounded-full pointer-events-none" />

        {/* Top Header */}
        <header className="h-20 border-b border-slate-800 flex items-center justify-between px-8 bg-card-dark/20 backdrop-blur-sm z-10 shrink-0">
          <div className="flex items-center gap-4">
             <div>
                <h2 className="text-xl font-display font-semibold tracking-tight">FitZone Intelligence Hub</h2>
                <div className="flex items-center gap-2 mt-0.5">
                   <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-[0_0_8px_#10b981]" />
                   <p className="text-[10px] font-mono text-slate-500 uppercase tracking-widest">Neural Link Established • Zone 01 Active</p>
                </div>
             </div>
          </div>

          <div className="flex items-center gap-6">
            <div className="hidden md:flex items-center bg-slate-900 border border-slate-800 rounded-full px-4 py-2 gap-2 w-64 group focus-within:border-blue-500/50 transition-all">
              <Search className="w-4 h-4 text-slate-500 group-focus-within:text-blue-400" />
              <input 
                type="text" 
                placeholder="Search telemetry data..." 
                className="bg-transparent border-none outline-none text-xs text-slate-300 w-full placeholder:text-slate-600"
              />
            </div>
            
            <div className="flex items-center gap-4">
              <button className="p-2.5 rounded-full bg-slate-900 border border-slate-800 text-slate-400 hover:text-white transition-all relative">
                <Bell className="w-4 h-4" />
                <span className="absolute top-2 right-2 w-2 h-2 bg-rose-500 rounded-full border-2 border-slate-900" />
              </button>
              <div className="w-px h-8 bg-slate-800 mx-1" />
              <button className="flex items-center gap-3 pl-2 group">
                <div className="text-right">
                  <p className="text-xs font-bold text-slate-200">Admin_Cordoba</p>
                  <p className="text-[10px] font-mono text-blue-500 uppercase">System Operator</p>
                </div>
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center border-2 border-slate-800 group-hover:border-blue-500/50 transition-all shadow-lg">
                  <User className="text-white w-5 h-5" />
                </div>
              </button>
            </div>
          </div>
        </header>

        {/* Dashboard Content */}
        <div className="flex-1 overflow-y-auto p-8 space-y-8 custom-scrollbar relative z-10">
          
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center justify-between"
          >
            <div>
               <h1 className="text-3xl font-display font-bold tracking-tight mb-1">
                 Welcome back, <span className="text-blue-500">David</span>
               </h1>
               <p className="text-slate-400 text-sm">All facility systems are operating within optimal parameters.</p>
            </div>
            <div className="flex gap-2">
               <button className="flex items-center gap-2 bg-slate-900 border border-slate-800 px-4 py-2 rounded-xl text-xs font-medium text-slate-400 hover:bg-slate-800 transition-all">
                  <Cpu className="w-4 h-4" /> Hardware Status
               </button>
               <button className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-xl text-xs font-bold shadow-lg shadow-blue-600/20 hover:bg-blue-500 transition-all">
                  <Shield className="w-4 h-4" /> Emergency Protocol
               </button>
            </div>
          </motion.div>

          {/* Stats Bar */}
          <StatSection />

          {/* Main Grid */}
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
            {/* Left Col: Analytics */}
            <div className="xl:col-span-2 space-y-8">
               <AttendanceChart />
               <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  <OccupancyChart />
                  <PredictionPanel />
               </div>
            </div>

            {/* Right Col: Operations */}
            <div className="h-full">
               <AlertsPanel />
            </div>
          </div>
        </div>
      </main>

      <FitZoneAssistant />
    </div>
  );
}
