export interface ZoneOccupancy {
  name: string;
  current: number;
  capacity: number;
  status: 'low' | 'medium' | 'high' | 'full';
}

export interface AttendanceData {
  day: string;
  count: number;
  expected: number;
}

export interface Alert {
  id: string;
  type: 'info' | 'warning' | 'error' | 'success';
  title: string;
  message: string;
  timestamp: string;
}

export interface SystemStatus {
  temperature: number;
  humidity: number;
  airQuality: string;
  prediction: string;
}
