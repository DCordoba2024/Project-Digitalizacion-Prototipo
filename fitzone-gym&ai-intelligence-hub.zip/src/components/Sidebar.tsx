import { motion } from 'motion/react';
import { 
  LayoutDashboard, 
  Users, 
  Calendar, 
  Settings, 
  Dumbbell, 
  Activity, 
  ShieldCheck,
  LogOut,
  ChevronRight
} from 'lucide-react';
import { cn } from '../lib/utils';
import { useState } from 'react';

const menuItems = [
  { icon: LayoutDashboard, label: 'Dashboard', active: true },
  { icon: Users, label: 'Members', active: false },
  { icon: Activity, label: 'Usage Stats', active: false },
  { icon: Calendar, label: 'Schedule', active: false },
  { icon: ShieldCheck, label: 'Security', active: false },
  { icon: Settings, label: 'Settings', active: false },
];

export const Sidebar = () => {
  const [isCollapsed, setIsCollapsed] = useState(false);

  return (
    <motion.div 
      initial={{ x: -100, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      className={cn(
        "h-screen bg-card-dark border-r border-slate-800 flex flex-col transition-all duration-500 relative z-50",
        isCollapsed ? "w-20" : "w-64"
      )}
    >
      <div className="p-6 flex items-center gap-3">
        <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center shadow-[0_0_20px_rgba(37,99,235,0.4)]">
          <Dumbbell className="text-white w-6 h-6" />
        </div>
        {!isCollapsed && (
          <motion.h1 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-xl font-display font-bold tracking-tight bg-gradient-to-r from-white to-slate-500 bg-clip-text text-transparent"
          >
            FitZone<span className="text-blue-500">Gym</span>
          </motion.h1>
        )}
      </div>

      <nav className="flex-1 px-4 mt-8 space-y-2">
        {menuItems.map((item, idx) => (
          <button
            key={idx}
            className={cn(
              "w-full flex items-center gap-4 p-3 rounded-xl transition-all group relative",
              item.active 
                ? "bg-blue-600 text-white shadow-[0_10px_30px_-10px_rgba(37,99,235,0.5)]" 
                : "text-slate-500 hover:bg-slate-800 hover:text-slate-300"
            )}
          >
            <item.icon className="w-5 h-5" />
            {!isCollapsed && (
               <span className="text-sm font-medium">{item.label}</span>
            )}
            {item.active && !isCollapsed && (
              <ChevronRight className="w-4 h-4 ml-auto opacity-50" />
            )}
            {isCollapsed && item.active && (
              <div className="absolute left-0 top-1/4 w-1 h-1/2 bg-white rounded-r-full" />
            )}
          </button>
        ))}
      </nav>

      <div className="p-4 border-t border-slate-800">
        {!isCollapsed && (
          <div className="bg-slate-900/50 p-4 rounded-xl mb-4 border border-slate-800/50">
            <div className="flex items-center gap-3 mb-2">
               <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
               <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest">Network Status</span>
            </div>
            <p className="text-[10px] text-slate-500 font-medium">Core Nodes: 48/48 Operational</p>
          </div>
        )}
        <button 
           onClick={() => setIsCollapsed(!isCollapsed)}
           className="w-full flex items-center gap-4 p-3 rounded-xl text-slate-500 hover:bg-slate-800 transition-all"
        >
          <LogOut className="w-5 h-5 rotate-180" />
          {!isCollapsed && <span className="text-sm font-medium">Collapse</span>}
        </button>
      </div>

      <button 
        onClick={() => setIsCollapsed(!isCollapsed)}
        className="absolute -right-3 top-20 bg-slate-800 border border-slate-700 rounded-full p-1 text-slate-400 hover:text-white transition-colors"
      >
        <ChevronRight className={cn("w-4 h-4 transition-transform", isCollapsed ? "" : "rotate-180")} />
      </button>
    </motion.div>
  );
};
