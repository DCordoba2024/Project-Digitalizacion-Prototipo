import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { motion } from 'motion/react';

const data = [
  { day: 'Mon', actual: 120, expected: 110 },
  { day: 'Tue', actual: 150, expected: 140 },
  { day: 'Wed', actual: 140, expected: 155 },
  { day: 'Thu', actual: 180, expected: 170 },
  { day: 'Fri', actual: 210, expected: 190 },
  { day: 'Sat', actual: 160, expected: 175 },
  { day: 'Sun', actual: 95, expected: 100 },
];

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-slate-900/90 backdrop-blur border border-slate-700 p-3 rounded-lg shadow-2xl">
        <p className="text-xs font-mono text-slate-400 mb-2">{label}</p>
        <div className="space-y-1">
          <div className="flex items-center justify-between gap-8">
            <span className="text-xs text-blue-400">Actual</span>
            <span className="text-sm font-display font-medium text-white">{payload[0].value}</span>
          </div>
          <div className="flex items-center justify-between gap-8">
            <span className="text-xs text-slate-500">Predicted</span>
            <span className="text-sm font-display font-medium text-slate-300">{payload[1].value}</span>
          </div>
        </div>
      </div>
    );
  }
  return null;
};

export const AttendanceChart = () => {
  return (
    <motion.div 
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      className="glass-panel p-6 h-[400px] flex flex-col"
    >
      <div className="flex justify-between items-center mb-6">
        <div>
          <h3 className="text-lg font-display font-medium">Weekly Attendance</h3>
          <p className="text-xs text-slate-500 mt-1 uppercase tracking-wider font-mono">Actual vs Predictive AI Model</p>
        </div>
        <div className="flex gap-2">
           <div className="flex items-center gap-1.5 bg-slate-800/50 px-3 py-1.5 rounded-full border border-slate-700">
             <div className="w-2 h-2 rounded-full bg-blue-500" />
             <span className="text-[10px] font-mono text-slate-400">Actual</span>
           </div>
           <div className="flex items-center gap-1.5 bg-slate-800/50 px-3 py-1.5 rounded-full border border-slate-700">
             <div className="w-2 h-2 rounded-full bg-slate-600" />
             <span className="text-[10px] font-mono text-slate-400">Predictive</span>
           </div>
        </div>
      </div>
      
      <div className="flex-1 min-h-0 -ml-4">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data}>
            <defs>
              <linearGradient id="colorActual" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#1e293b" />
            <XAxis 
              dataKey="day" 
              axisLine={false} 
              tickLine={false} 
              tick={{ fill: '#64748b', fontSize: 10, fontWeight: 500 }}
              dy={10}
            />
            <YAxis 
              axisLine={false} 
              tickLine={false} 
              tick={{ fill: '#64748b', fontSize: 10, fontWeight: 500 }}
            />
            <Tooltip content={<CustomTooltip />} cursor={{ stroke: '#334155', strokeWidth: 1 }} />
            <Area 
              type="monotone" 
              dataKey="actual" 
              stroke="#3b82f6" 
              strokeWidth={3}
              fillOpacity={1} 
              fill="url(#colorActual)" 
              animationDuration={1500}
            />
            <Area 
              type="monotone" 
              dataKey="expected" 
              stroke="#475569" 
              strokeWidth={2}
              strokeDasharray="5 5"
              fill="transparent" 
              animationDuration={1500}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </motion.div>
  );
};
