import { motion } from 'motion/react';
import { Brain, TrendingDown, Clock, MoveRight } from 'lucide-react';

export const PredictionPanel = () => {
  const hours = [
    { time: '17:00', level: 85, color: 'bg-rose-500' },
    { time: '18:00', level: 95, color: 'bg-rose-600' },
    { time: '19:00', level: 70, color: 'bg-amber-500' },
    { time: '20:00', level: 45, color: 'bg-emerald-500' },
    { time: '21:00', level: 30, color: 'bg-emerald-600' },
    { time: '22:00', level: 15, color: 'bg-blue-500' },
  ];

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="glass-panel p-6 bg-gradient-to-br from-blue-900/20 to-card-dark relative overflow-hidden"
    >
      <div className="absolute top-[-20%] right-[-10%] w-64 h-64 bg-blue-500/5 blur-[100px] rounded-full" />
      
      <div className="relative z-10">
        <div className="flex items-center gap-2 mb-6">
          <div className="p-2 bg-blue-500/20 rounded-lg">
            <Brain className="w-5 h-5 text-blue-400" />
          </div>
          <div>
            <h3 className="text-lg font-display font-medium">AI Crowd Forecast</h3>
            <p className="text-[10px] font-mono text-slate-500 uppercase tracking-widest">Neural Engine Prediction</p>
          </div>
        </div>

        <div className="flex items-center gap-4 bg-emerald-500/10 border border-emerald-500/20 p-4 rounded-xl mb-8">
          <TrendingDown className="w-8 h-8 text-emerald-400" />
          <div>
            <p className="text-sm font-medium text-emerald-400">Mejor momento para entrenar</p>
            <p className="text-xl font-display font-bold">Hoy: 15:00 - 17:00</p>
            <p className="text-xs text-slate-400 mt-1">Afluencia mínima detectada</p>
          </div>
        </div>

        <div className="space-y-4">
          <h4 className="text-xs font-mono text-slate-500 uppercase tracking-widest flex items-center gap-2">
            <Clock className="w-3 h-3" /> Proyección Horaria
          </h4>
          
          <div className="flex items-end justify-between h-24 gap-2">
            {[
              { time: '15:00', level: 20, color: 'bg-emerald-500' },
              { time: '16:00', level: 25, color: 'bg-emerald-500' },
              { time: '17:00', level: 40, color: 'bg-amber-500' },
              { time: '18:00', level: 85, color: 'bg-rose-500' },
              { time: '19:00', level: 95, color: 'bg-rose-600' },
              { time: '20:00', level: 90, color: 'bg-rose-500' },
            ].map((item, idx) => (
              <div key={idx} className="flex-1 flex flex-col items-center gap-2 group">
                <div className="w-full relative bg-slate-800 rounded-t-sm overflow-hidden h-full">
                  <motion.div 
                    initial={{ height: 0 }}
                    animate={{ height: `${item.level}%` }}
                    transition={{ duration: 1, delay: idx * 0.1 }}
                    className={`absolute bottom-0 w-full ${item.color} opacity-80 group-hover:opacity-100 transition-opacity`}
                  />
                </div>
                <span className="text-[9px] font-mono text-slate-500">{item.time}</span>
              </div>
            ))}
          </div>
        </div>

        <button className="mt-8 w-full group flex items-center justify-between p-4 bg-slate-800/50 hover:bg-slate-800 rounded-xl transition-all border border-slate-700/50">
          <span className="text-xs font-medium text-slate-300">Detailed Traffic Analysis</span>
          <MoveRight className="w-4 h-4 text-slate-500 group-hover:text-blue-400 group-hover:translate-x-1 transition-all" />
        </button>
      </div>
    </motion.div>
  );
};
