import { motion } from 'motion/react';
import { Thermometer, Users, Zap, Wind } from 'lucide-react';
import { cn } from '../lib/utils';
import React from 'react';

interface StatProps {
  label: string;
  value: string | number;
  unit?: string;
  icon: React.ElementType;
  trend?: {
    value: number;
    isUp: boolean;
  };
  color: string;
  key?: React.Key;
}

const StatCard = ({ label, value, unit, icon: Icon, trend, color }: StatProps) => {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass-panel p-6 flex items-start justify-between group hover:border-slate-700 transition-colors"
    >
      <div>
        <p className="stat-label mb-2">{label}</p>
        <div className="flex items-baseline gap-1">
          <h3 className="stat-value">{value}</h3>
          {unit && <span className="text-slate-500 font-display font-light">{unit}</span>}
        </div>
        {trend && (
          <p className={cn(
            "text-xs mt-2 flex items-center gap-1 font-medium",
            trend.isUp ? "text-emerald-400" : "text-rose-400"
          )}>
            {trend.isUp ? '↑' : '↓'} {Math.abs(trend.value)}% 
            <span className="text-slate-500 font-normal">vS last hour</span>
          </p>
        )}
      </div>
      <div className={cn(
        "p-3 rounded-xl transition-all duration-500",
        color
      )}>
        <Icon className="w-5 h-5 text-white" />
      </div>
    </motion.div>
  );
};

interface StatSectionProps {
  telemetry: {
    temp: number;
    occupancy: number;
    activeMembers: number;
    energyUsage: number;
    airQuality: string;
  };
}

export const StatSection = ({ telemetry }: StatSectionProps) => {
  const stats: StatProps[] = [
    {
      label: "Indoor Temp",
      value: telemetry.temp,
      unit: "°C",
      icon: Thermometer,
      trend: { value: 0.2, isUp: true },
      color: "bg-blue-500/20 text-blue-400 shadow-[0_0_15px_rgba(59,130,246,0.3)]"
    },
    {
      label: "Live Occupancy",
      value: telemetry.occupancy,
      unit: "%",
      icon: Users,
      trend: { value: 5, isUp: true },
      color: "bg-cyan-500/20 text-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.3)]"
    },
    {
      label: "Active Members",
      value: telemetry.activeMembers,
      unit: "users",
      icon: Users,
      color: "bg-violet-500/20 text-violet-400 shadow-[0_0_15px_rgba(139,92,246,0.3)]"
    },
    {
      label: "Energy Usage",
      value: telemetry.energyUsage,
      unit: "kW/h",
      icon: Zap,
      trend: { value: 4, isUp: false },
      color: "bg-emerald-500/20 text-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.3)]"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {stats.map((stat, idx) => (
        <StatCard key={idx} {...stat} />
      ))}
    </div>
  );
};
