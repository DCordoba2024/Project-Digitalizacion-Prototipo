import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { motion } from 'motion/react';

const data = [
  { name: 'Musculación', value: 85, color: '#3b82f6' },
  { name: 'Cardio', value: 60, color: '#06b6d4' },
  { name: 'Clases Dirigidas', value: 40, color: '#10b981' },
];

const CustomTooltip = ({ active, payload }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-slate-900 border border-slate-700 p-2 rounded shadow-xl">
        <p className="text-xs font-mono text-slate-300">{payload[0].name}</p>
        <p className="text-lg font-display text-white">{payload[0].value}% <span className="text-xs text-slate-500">occupancy</span></p>
      </div>
    );
  }
  return null;
};

export const OccupancyChart = () => {
  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="glass-panel p-6 h-[400px] flex flex-col"
    >
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-lg font-display font-medium">Zone Distribution</h3>
        <span className="text-[10px] font-mono text-cyan-400 bg-cyan-400/10 px-2 py-1 rounded border border-cyan-400/20 uppercase tracking-tighter">Real-time IoT Feed</span>
      </div>
      
      <div className="flex-1 min-h-0">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              innerRadius={60}
              outerRadius={80}
              paddingAngle={5}
              dataKey="value"
              stroke="none"
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Pie>
            <Tooltip content={<CustomTooltip />} />
            <Legend 
              verticalAlign="bottom" 
              height={36}
              content={({ payload }: any) => (
                <ul className="flex flex-wrap justify-center gap-4 mt-4">
                  {payload.map((entry: any, index: number) => (
                    <li key={`item-${index}`} className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full" style={{ backgroundColor: entry.color }} />
                      <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">{entry.value}</span>
                    </li>
                  ))}
                </ul>
              )}
            />
          </PieChart>
        </ResponsiveContainer>
      </div>
    </motion.div>
  );
};
