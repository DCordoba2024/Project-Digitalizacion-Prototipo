import { motion } from 'motion/react';
import { AlertCircle, CheckCircle2, Info, AlertTriangle, Clock } from 'lucide-react';
import { cn } from '../lib/utils';

const alerts = [
  {
    id: '1',
    type: 'warning',
    title: 'High Occupancy Zone',
    message: 'Weight Room approaching 90% capacity. Ventilation increased.',
    timestamp: '2 mins ago',
    icon: AlertTriangle,
    color: 'text-amber-400 bg-amber-400/10 border-amber-400/20'
  },
  {
    id: '2',
    type: 'success',
    title: 'Air Quality Purified',
    message: 'HEPA filtration cycle completed in Yoga Studio.',
    timestamp: '15 mins ago',
    icon: CheckCircle2,
    color: 'text-emerald-400 bg-emerald-400/10 border-emerald-400/20'
  },
  {
    id: '3',
    type: 'info',
    title: 'System Update',
    message: 'IoT Node #42 (Locker Room) firmware updated successfully.',
    timestamp: '1 hour ago',
    icon: Info,
    color: 'text-blue-400 bg-blue-400/10 border-blue-400/20'
  },
  {
    id: '4',
    type: 'error',
    title: 'Maintenance Required',
    message: 'Treadmill #04 reporting motor calibration error.',
    timestamp: '3 hours ago',
    icon: AlertCircle,
    color: 'text-rose-400 bg-rose-400/10 border-rose-400/20'
  }
];

export const AlertsPanel = () => {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass-panel h-full flex flex-col"
    >
      <div className="p-6 border-b border-slate-800 flex justify-between items-center">
        <h3 className="text-lg font-display font-medium">System Alarms</h3>
        <span className="bg-rose-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full animate-pulse">4 ACTIVE</span>
      </div>
      
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {alerts.map((alert, idx) => (
          <motion.div 
            key={alert.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: idx * 0.1 }}
            className={cn(
              "p-4 rounded-xl border flex gap-4 items-start group hover:scale-[1.02] transition-transform cursor-pointer",
              alert.color
            )}
          >
            <alert.icon className="w-5 h-5 mt-0.5 shrink-0" />
            <div className="flex-1 min-w-0">
              <div className="flex justify-between items-start mb-1">
                <h4 className="text-sm font-bold truncate">{alert.title}</h4>
                <div className="flex items-center gap-1 text-[10px] opacity-60 font-mono">
                  <Clock className="w-3 h-3" />
                  {alert.timestamp}
                </div>
              </div>
              <p className="text-xs opacity-80 leading-relaxed font-light">{alert.message}</p>
            </div>
          </motion.div>
        ))}
      </div>
      
      <div className="p-4 border-top border-slate-800">
        <button className="w-full py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-mono uppercase tracking-widest transition-colors text-slate-400">
          View All Logs
        </button>
      </div>
    </motion.div>
  );
};
